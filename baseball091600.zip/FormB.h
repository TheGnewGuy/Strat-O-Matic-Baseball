// FormB.h: interface for the FormB class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FORMB_H__F85F0EA1_89B9_11D2_B0EE_444553540000__INCLUDED_)
#define AFX_FORMB_H__F85F0EA1_89B9_11D2_B0EE_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class FormB  
{
public:
	void OnDraw(CDC* pDC, CBaseballDoc* pDoc);
	FormB();
	virtual ~FormB();

};

#endif // !defined(AFX_FORMB_H__F85F0EA1_89B9_11D2_B0EE_444553540000__INCLUDED_)
